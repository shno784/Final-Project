export interface ProcessImageProps {
  uri: string;
}

export interface BarcodeProps {
  type: string;
  data: string;
}
