export function extractNutrients(
    rawData: 
      | Record<string, number> 
      | string 
      | Array<{ name: string; value: number }>
  ): Array<{ name: string; value: number }> {
    // If it’s a JSON string, parse it.
    let data: any = rawData;
    if (typeof data === "string") {
      try {
        data = JSON.parse(data);
      } catch {
        console.warn("extractNutrients: failed to parse JSON string");
        return [];
      }
    }
  
    // If it’s already an array of {name, value}, just return it.
    if (Array.isArray(data)) {
      return data.map(({ name, value }) => ({ name, value }));
    }
  
    // 3️⃣ Otherwise assume it’s an object map { nutrientName: number }
    if (data && typeof data === "object") {
      return Object.entries(data).map(([name, val]) => ({
        name,
        value: val as number,
      }));
    }
  
    // 4️⃣ Fallback
    return [];
  }
  