import { BarcodeScan } from "@/service/OpenFoodFacts";
import { FoodItem } from "@/types/FoodTypes";

// This function processes a barcode by scanning it and inserting the food item into the database
const ProcessBarcode = async (
  barcode: string,
  insertFoodItem: (food: FoodItem) => Promise<void>
) => {
  try {
    const data: FoodItem = await BarcodeScan(barcode);
    insertFoodItem(data);
    return { success: true };
  } catch (error) {
    console.error("Error processing barcode:", error);
    return { success: false };
  }
};

export default ProcessBarcode;
